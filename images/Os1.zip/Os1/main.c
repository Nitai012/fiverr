#include <stdio.h>
#include <stdlib.h>

typedef struct phone{
    char first_name[20];
    char last_name[20];
    char phone_num[15];
} Phone;

int main(){
    Phone *phn = malloc(sizeof(Phone));
    FILE *ptr = fopen("phones.dat", "r");
    if(ptr == NULL){
        perror("Error: ");
        return EXIT_FAILURE;
    }
    fseek(ptr, 0, SEEK_SET);
    const int always=1;
    while (always==1){
        int rd = fread(phn, sizeof(Phone), 1, ptr);
        if (rd < 1)
            break;
        printf("First name: %s\n", phn->first_name);
        printf("Last name: %s\n", phn->last_name);
        printf("Phone number: %s\n", phn->phone_num);
    }
    free(phn);
    return EXIT_SUCCESS;
}